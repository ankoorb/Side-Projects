# Imports
from flask import Flask
from flask import render_template
from flask import request

import os
import pickle
import numpy as np

# Create an instance of class "Flask" with name of running application as the arg
app = Flask(__name__)

# Index page
@app.route('/')
def index():
    return render_template('index.html')

# About page
@app.route('/about')
def about():
	return render_template('about.html')

# Model page
@app.route('/model')
def model():
	return render_template('model.html')

app_dir = os.path.dirname(__file__)

@app.route('/', methods=['POST'])
def valuate():
    
    # Get submitted values
    area = int(request.form['area']) # Convert str to int
    beds = request.form['beds']
    baths = request.form['baths']
    pool = request.form['pool']
    dwelling = request.form['dwelling']
    temp_list = [beds, baths, pool, dwelling]
    
    # Load input_dict and input list
    dict_path = os.path.join(app_dir, 'model', 'input_dict.pkl')
    list_path = os.path.join(app_dir, 'model', 'input_list.pkl')
    input_dict = pickle.load(open(dict_path, 'rb'))
    input_list = pickle.load(open(list_path, 'rb'))
    
    # Update dict
    input_dict['area'] = area
    for key in temp_list:
        input_dict[key] = 1
        
    # List of input values after updating dict
    input_vals = [input_dict[i] for i in input_list]
    
    # Input array for prediction
    input_array = np.array(input_vals).reshape(1, -1)
    
    # Load model to predict
    model_path = os.path.join(app_dir, 'model', 'regression.pkl')
    model = pickle.load(open(model_path, 'rb'))
    
    # Predict
    temp_val = model.predict(input_array)[0]
    val = "{:,}".format(int(temp_val))
    return render_template('index.html', result=val)
    


if __name__ == '__main__':

    # Debug mode gives detailed message in case of an error.
    # NOTE: Debug mode is HIGHLY INSECURE
    app.run(debug=True)
    
 