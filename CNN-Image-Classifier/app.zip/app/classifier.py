import numpy as np
from PIL import Image

from layers import *
from fast_layers import *
from layer_utils import *



# Resize Image
def resize_image(img):
    """
    input: 
        img = PIL image
    """
    SIZE = 96
    # Resizing image
    x, y = img.size
    if x > y:
        nx = SIZE
        ny = int(SIZE * y/x + 0.5)
    else:
        nx = int(SIZE * x/y + 0.5)
        ny = SIZE
    temp_res = img.resize((nx, ny), resample=Image.ANTIALIAS)
    # Padding borders to create a square image
    temp_pad = Image.new('RGB', (SIZE, SIZE), (128, 128, 128))
    temp = ((SIZE - nx)//2, (SIZE - ny)//2)
    temp_pad.paste(temp_res, temp)
    return temp_pad

# Image to Numpy Array
def image_to_array(img):
    try:
        arr = np.asarray(img, dtype='uint8')
    except SystemError:
        arr = np.asarray(img, dtype='uint8')
    return arr.T

# Array for model
def data_array(arr, x_mean, x_std):
	temp = (arr - x_mean)/x_std
	return temp

def predict(x, params):
    # Parameters
    W1, b1 = params['W1'], params['b1']
    W2, b2 = params['W2'], params['b2']
    W3, b3 = params['W3'], params['b3']
    filter_size = 7
    conv_param = {'stride': 1, 'pad': (filter_size - 1) / 2}
    pool_param = {'pool_height': 2, 'pool_width': 2, 'stride': 2}
    # Forward Pass
    out1, _ = conv_relu_pool_forward(x, W1, b1, conv_param, pool_param)
    N, num_filters, HH, WW = out1.shape
    out1_flattened = out1.reshape(N, num_filters * HH * WW)
    out2, _ = affine_relu_forward(out1_flattened, W2, b2)
    out3, _ = affine_forward(out2, W3, b3)
    probs = np.exp(out3 - np.max(out3, axis=1, keepdims=True))
    probs /= np.sum(probs, axis=1, keepdims=True)
    cls = np.argmax(probs, axis=1)[0]
    prob = np.round(np.max(probs, axis=1)[0], 3)
    return cls, prob
