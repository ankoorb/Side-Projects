import numpy as np

def affine_forward(x, w, b):
    N = x.shape[0]
    xdim = np.prod(x.shape[1:])
    xr = x.reshape((N, xdim))
    out = xr.dot(w) + b
    cache = (x, w, b)
    return out, cache

def relu_forward(x):
    out = np.maximum(x, 0)
    cache = x
    return out, cache


