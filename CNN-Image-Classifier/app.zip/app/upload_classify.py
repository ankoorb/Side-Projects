# Imports
from flask import Flask
from flask import render_template
from flask import send_from_directory
from flask import request

import os
import pickle

from PIL import Image
import numpy as np
import classifier as clf # CNN
#-----------------------------------------------------------------------------#

# Create an instance of class "Flask" with name of running application as the arg
app = Flask(__name__)

APP_ROOT = os.path.dirname(os.path.abspath(__file__))

app.config['UPLOAD_FOLDER'] = 'image/'

# Index page
@app.route('/')
def index():
    return render_template('index.html')

# About page
@app.route('/about')
def about():
	return render_template('about.html')

# CNN page
@app.route('/cnn')
def cnn():
	return render_template('cnn.html')

# Upload and classify
@app.route('/', methods=['POST'])
def upload():
	target = os.path.join(APP_ROOT, 'image')
	# Remove: "temp.jpg"
	file_list = os.listdir(target)
	for f in file_list:
		os.remove(os.path.join(target, f))
	File = request.files['dogcat']
	#file_name = 'temp.jpg'
	file_name = File.filename
	print file_name
	destination = '/'.join([target, file_name])
	File.save(destination)

	###---------------- CNN ---------------###
	temp_img = Image.open(destination)
	temp_res = clf.resize_image(temp_img)
	temp_arr = clf.image_to_array(temp_res)

	# Model paths
	model_path = os.path.join(APP_ROOT, 'model', 'model_4.pkl')
	mean_path = os.path.join(APP_ROOT, 'model', 'avg_4.pkl')
	std_path = os.path.join(APP_ROOT, 'model', 'std_4.pkl')
	params = pickle.load(open(model_path, 'rb'))
	means = pickle.load(open(mean_path, 'rb'))
	stds = pickle.load(open(std_path, 'rb'))

	std_arr = clf.data_array(temp_arr, means, stds)

	input_arr = np.ndarray((1, 3, 96, 96), dtype='float64')
	input_arr[0] = std_arr
	output, p = clf.predict(input_arr, params)
	out = ''
	if output == 1:
		out = 'Dog'
	else:
		out = 'Cat'

	#img_list = os.listdir('./image')
	#print img_list
	#img = 'http://127.0.0.1:5000/upload/' + file_name
	#return render_template('classify.html', image_name=img, result=out)
	print output, p

	return render_template('classify.html', image_name=file_name, result=out, prob=p)


# Loading uploaded dog/cat image
@app.route('/upload/<filename>', methods=['GET'])
def load_image(filename):
	return send_from_directory(app.config['UPLOAD_FOLDER'], filename)



if __name__ == '__main__':

    # Debug mode gives detailed message in case of an error.
    # NOTE: Debug mode is HIGHLY INSECURE
    app.run(debug=True)





#  # Upload
# @app.route('/upload', methods=['POST'])
# def upload():
# 	target = os.path.join(APP_ROOT, 'image')
# 	# Remove: "temp.jpg"
# 	# file_list = os.listdir(target)
# 	# for f in file_list:
# 	# 	os.remove(os.path.join(target, f))
# 	File = request.files['dogcat']
# 	file_name = 'temp.jpg'
# 	destination = '/'.join([target, file_name])
# 	File.save(destination)

# 	###---------------- CNN ---------------###
# 	temp_img = Image.open(destination)
# 	temp_res = clf.resize_image(temp_img)
# 	temp_arr = clf.image_to_array(temp_res)

# 	# Model paths
# 	model_path = os.path.join(APP_ROOT, 'model', 'model_4.pkl')
# 	mean_path = os.path.join(APP_ROOT, 'model', 'avg_4.pkl')
# 	std_path = os.path.join(APP_ROOT, 'model', 'std_4.pkl')
# 	params = pickle.load(open(model_path, 'rb'))
# 	means = pickle.load(open(mean_path, 'rb'))
# 	stds = pickle.load(open(std_path, 'rb'))

# 	std_arr = clf.data_array(temp_arr, means, stds)

# 	input_arr = np.ndarray((1, 3, 96, 96), dtype='float64')
# 	input_arr[0] = std_arr
# 	output = clf.predict(input_arr, params)
# 	out = ''
# 	if output == 1:
# 		out = 'Dog'
# 	else:
# 		out = 'Cat'

# 	#img_list = os.listdir('./image')
# 	#print img_list
# 	#img = 'http://127.0.0.1:5000/upload/' + file_name
# 	#return render_template('classify.html', image_name=img, result=out)

# 	return render_template('classify.html', image_name=file_name, result=out)

