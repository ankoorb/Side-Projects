$(document).ready(function(){
	console.log("ready!");
	
	// Add onsubmit="return false" in the <form>
	$("form").on('submit', function(){
		console.log("the form has been submitted.")
	});
});