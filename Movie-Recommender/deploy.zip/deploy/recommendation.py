# Imports
from flask import Flask
from flask import render_template
from flask import send_from_directory
from flask import request

import os
import pickle

# Create an instance of class "Flask" with name of running application as the arg
app = Flask(__name__)

# Index page
@app.route('/')
def index():
    return render_template('index.html')

# About page
@app.route('/about')
def about():
	return render_template('about.html')

# Algorithm page
@app.route('/algorithm')
def algorithm():
	return render_template('algorithm.html')

# Loading recommended movie posters
@app.route('/<filename>')
def load_image(filename):
	return send_from_directory('images', filename)

app_dir = os.path.dirname(__file__)

# Recommendation page
@app.route('/', methods=['POST'])
def gallery():
	try:
		temp = request.form['title']
	except Exception as e:
		temp = None
	model_path = os.path.join(app_dir, 'model', 'movies.pkl')
	data = pickle.load(open(model_path, 'rb'))
	try:
		image_names = data[temp.lower()]['images'].values()
	except Exception as e:
		image_names = ['image_error.jpg']
	return render_template('recs.html', movie_title = temp, image_names=image_names)


if __name__ == '__main__':

    # Debug mode gives detailed message in case of an error.
    # NOTE: Debug mode is HIGHLY INSECURE
    app.run(debug=True)